import React, { useState } from 'react';
import { X, ChevronDown, Database, Loader, AlertCircle } from 'lucide-react';

interface DataSource {
  id: string;
  name: string;
  type: 'postgres' | 'mysql' | 'mongodb' | 'api';
  status: 'connected' | 'disconnected' | 'error';
}

interface ChatPanelProps {
  isOpen: boolean;
  onClose: () => void;
}

const mockDataSources: DataSource[] = [
  { id: '1', name: 'Main Database', type: 'postgres', status: 'connected' },
  { id: '2', name: 'Analytics DB', type: 'mysql', status: 'connected' },
  { id: '3', name: 'Legacy System', type: 'mongodb', status: 'error' },
];

export function ChatPanel({ isOpen, onClose }: ChatPanelProps) {
  const [selectedSource, setSelectedSource] = useState<DataSource | null>(mockDataSources[0]);
  const [isSourceDropdownOpen, setIsSourceDropdownOpen] = useState(false);
  const [message, setMessage] = useState('');

  const getStatusColor = (status: DataSource['status']) => {
    switch (status) {
      case 'connected':
        return 'bg-green-500';
      case 'disconnected':
        return 'bg-gray-500';
      case 'error':
        return 'bg-red-500';
    }
  };

  return (
    <div
      className={`fixed right-0 top-0 h-full w-96 bg-white shadow-xl transform transition-transform duration-300 ease-in-out ${
        isOpen ? 'translate-x-0' : 'translate-x-full'
      }`}
    >
      {/* Header */}
      <div className="border-b border-gray-200 p-4">
        <div className="flex items-center justify-between">
          <h2 className="text-lg font-semibold">Data Chat</h2>
          <button
            onClick={onClose}
            className="p-1 hover:bg-gray-100 rounded-full transition-colors"
            aria-label="Close chat"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Data Source Selector */}
        <div className="mt-4 relative">
          <button
            onClick={() => setIsSourceDropdownOpen(!isSourceDropdownOpen)}
            className="w-full flex items-center justify-between p-2 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
          >
            <div className="flex items-center space-x-2">
              <Database className="w-4 h-4 text-gray-500" />
              <span>{selectedSource?.name || 'Select a data source'}</span>
              {selectedSource && (
                <span className={`w-2 h-2 rounded-full ${getStatusColor(selectedSource.status)}`} />
              )}
            </div>
            <ChevronDown className="w-4 h-4 text-gray-500" />
          </button>

          {/* Dropdown Menu */}
          {isSourceDropdownOpen && (
            <div className="absolute top-full left-0 right-0 mt-1 bg-white border border-gray-200 rounded-lg shadow-lg z-50">
              {mockDataSources.map((source) => (
                <button
                  key={source.id}
                  onClick={() => {
                    setSelectedSource(source);
                    setIsSourceDropdownOpen(false);
                  }}
                  className="w-full flex items-center justify-between p-3 hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center space-x-2">
                    <Database className="w-4 h-4 text-gray-500" />
                    <span>{source.name}</span>
                  </div>
                  <span className={`w-2 h-2 rounded-full ${getStatusColor(source.status)}`} />
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Chat Messages */}
      <div className="flex-1 overflow-y-auto p-4 h-[calc(100%-13rem)]">
        {selectedSource?.status === 'error' ? (
          <div className="flex items-center justify-center h-full text-center text-gray-500">
            <div className="flex flex-col items-center space-y-2">
              <AlertCircle className="w-8 h-8 text-red-500" />
              <p>Unable to connect to {selectedSource.name}</p>
              <button className="text-sm text-purple-600 hover:text-purple-700">
                Retry Connection
              </button>
            </div>
          </div>
        ) : (
          <div className="flex items-center justify-center h-full text-center text-gray-500">
            <p>Start a conversation with your data</p>
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="border-t border-gray-200 p-4">
        <div className="flex items-center space-x-2">
          <input
            type="text"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Ask about your data..."
            className="flex-1 p-2 border border-gray-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
            disabled={selectedSource?.status !== 'connected'}
          />
          <button
            className="p-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            disabled={!message.trim() || selectedSource?.status !== 'connected'}
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
}