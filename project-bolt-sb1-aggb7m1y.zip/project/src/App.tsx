import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  Database, 
  Brain, 
  Workflow, 
  MessageSquare,
  Bell,
  User,
  ChevronDown,
  BarChart3,
  ArrowUpRight,
  Settings,
  Plus,
  HelpCircle,
  MessageCircle
} from 'lucide-react';
import { ChatPanel } from './components/ChatPanel';
import { DataSourceManager } from './components/DataSourceManager';

// Sidebar navigation items
const navItems = [
  { name: 'Data & Insights', icon: Database, section: 'data', description: 'Connect and analyze your data sources' },
  { name: 'Decisions', icon: Brain, section: 'decisions', description: 'Create and manage decision rules' },
  { name: 'Automations', icon: Workflow, section: 'automations', description: 'Build automated workflows' },
  { name: 'Communications', icon: MessageSquare, section: 'communications', description: 'Manage chat and voice agents' }
];

// Mock data for overview cards
const overviewData = [
  { title: 'Active Data Sources', value: '12', trend: '+2.5%', timeframe: 'vs last month' },
  { title: 'Decision Rules', value: '24', trend: '+5%', timeframe: 'vs last month' },
  { title: 'Active Automations', value: '8', trend: '+1.2%', timeframe: 'vs last month' },
  { title: 'Chat Sessions', value: '1.2k', trend: '+12%', timeframe: 'vs last month' }
];

// Mock recent activity data
const recentActivity = [
  { type: 'data', message: 'New CRM data source connected', time: '2 mins ago' },
  { type: 'decisions', message: 'Decision rule "High Value Lead" created', time: '15 mins ago' },
  { type: 'automations', message: 'Email automation triggered 50 times', time: '1 hour ago' },
  { type: 'communications', message: 'Chatbot response time improved by 15%', time: '2 hours ago' }
];

function App() {
  const [activeSection, setActiveSection] = useState('data');
  const [showHelp, setShowHelp] = useState(false);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isChatOpen, setIsChatOpen] = useState(false);

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Collapsible Sidebar */}
      <div 
        className="relative group"
        onMouseEnter={() => setIsSidebarOpen(true)}
        onMouseLeave={() => setIsSidebarOpen(false)}
      >
        <aside className={`bg-white border-r border-gray-200 flex flex-col h-full sidebar-transition ${isSidebarOpen ? 'sidebar-expanded' : 'sidebar-collapsed'}`}>
          <div className="p-6 border-b border-gray-200">
            <div className="flex items-center space-x-3">
              <LayoutDashboard className="w-8 h-8 text-purple-600 flex-shrink-0" />
              {isSidebarOpen && (
                <div className="animate-fade-in">
                  <h1 className="text-xl font-semibold">Ciro AI</h1>
                  <p className="text-sm text-gray-500">From Data to Action</p>
                </div>
              )}
            </div>
          </div>

          <nav className="flex-1 p-4 space-y-2">
            {navItems.map((item) => (
              <button
                key={item.section}
                onClick={() => setActiveSection(item.section)}
                className={`nav-item ${
                  activeSection === item.section
                    ? 'nav-item-active'
                    : 'nav-item-inactive'
                }`}
              >
                <div className="has-tooltip">
                  <item.icon className="w-5 h-5 flex-shrink-0" />
                  {!isSidebarOpen && (
                    <span className="tooltip left-14">{item.name}</span>
                  )}
                </div>
                {isSidebarOpen && (
                  <div className="ml-3 flex-1 text-left animate-fade-in">
                    <span>{item.name}</span>
                    <p className="text-xs text-gray-500 mt-0.5">{item.description}</p>
                  </div>
                )}
              </button>
            ))}
          </nav>

          <div className="p-4 border-t border-gray-200">
            <button 
              onClick={() => setShowHelp(!showHelp)}
              className="has-tooltip flex items-center space-x-2 text-gray-600 hover:text-purple-600 transition-colors duration-200"
            >
              <HelpCircle className="w-5 h-5" />
              {!isSidebarOpen && (
                <span className="tooltip left-14">Help & Resources</span>
              )}
              {isSidebarOpen && <span className="animate-fade-in">Help & Resources</span>}
            </button>
          </div>
        </aside>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top Bar */}
        <header className="bg-white border-b border-gray-200">
          <div className="flex items-center justify-between px-6 py-4">
            <h1 className="text-2xl font-semibold text-gray-800">Dashboard</h1>
            <div className="flex items-center space-x-4">
              <button className="relative p-2 text-gray-400 hover:text-gray-600">
                <Bell className="w-6 h-6" />
                <span className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full"></span>
              </button>
              <div className="flex items-center space-x-3 border-l border-gray-200 pl-4">
                <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                  <User className="w-6 h-6 text-purple-600" />
                </div>
                <div className="flex items-center space-x-2">
                  <div>
                    <p className="text-sm font-medium">John Doe</p>
                    <p className="text-xs text-gray-500">Admin</p>
                  </div>
                  <ChevronDown className="w-4 h-4 text-gray-400" />
                </div>
              </div>
            </div>
          </div>
        </header>

        {/* Content Area */}
        <main className="flex-1 overflow-y-auto p-6 space-y-6">
          {activeSection === 'data' ? (
            <DataSourceManager />
          ) : (
            <>
              {/* Overview Cards */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {overviewData.map((card, index) => (
                  <div key={index} className="stat-card">
                    <div className="flex items-center justify-between mb-4">
                      <div className="p-2 bg-purple-50 rounded-lg">
                        {index === 0 ? <BarChart3 className="w-6 h-6 text-purple-600" /> :
                         index === 1 ? <Brain className="w-6 h-6 text-purple-600" /> :
                         index === 2 ? <Workflow className="w-6 h-6 text-purple-600" /> :
                         <MessageSquare className="w-6 h-6 text-purple-600" />}
                      </div>
                      <span className="flex items-center text-sm text-green-600 bg-green-50 px-2 py-1 rounded">
                        {card.trend}
                        <ArrowUpRight className="w-4 h-4 ml-1" />
                      </span>
                    </div>
                    <h3 className="text-gray-500 text-sm">{card.title}</h3>
                    <p className="text-2xl font-semibold mt-1">{card.value}</p>
                    <p className="text-xs text-gray-500 mt-1">{card.timeframe}</p>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Main Section Content */}
                <div className="lg:col-span-2 section-card p-6">
                  <div className="flex items-center justify-between mb-6">
                    <div>
                      <h2 className="text-xl font-semibold text-gray-800">
                        {activeSection === 'data' && 'Data Analysis'}
                        {activeSection === 'decisions' && 'Decision Rules'}
                        {activeSection === 'automations' && 'Workflow Automations'}
                        {activeSection === 'communications' && 'Communication Channels'}
                      </h2>
                      <p className="text-sm text-gray-500 mt-1">
                        {activeSection === 'data' && 'Analyze and visualize your data'}
                        {activeSection === 'decisions' && 'Manage your decision rules'}
                        {activeSection === 'automations' && 'Create and monitor workflows'}
                        {activeSection === 'communications' && 'Manage communication channels'}
                      </p>
                    </div>
                    <div className="flex space-x-3">
                      <button className="btn-primary has-tooltip">
                        <Plus className="w-4 h-4" />
                        <span>Add New</span>
                        <span className="tooltip -bottom-8">Add new {activeSection} item</span>
                      </button>
                      <button className="btn-primary has-tooltip">
                        <Settings className="w-4 h-4" />
                        <span>Configure</span>
                        <span className="tooltip -bottom-8">Configure {activeSection} settings</span>
                      </button>
                    </div>
                  </div>
                  
                  {/* Placeholder content */}
                  <div className="h-96 flex items-center justify-center border-2 border-dashed border-gray-200 rounded-lg">
                    <p className="text-gray-500">
                      {activeSection === 'data' && 'Data visualization and insights will appear here'}
                      {activeSection === 'decisions' && 'Decision rules and models will appear here'}
                      {activeSection === 'automations' && 'Automation workflows will appear here'}
                      {activeSection === 'communications' && 'Communication channels and stats will appear here'}
                    </p>
                  </div>
                </div>

                {/* Recent Activity */}
                <div className="section-card p-6">
                  <h2 className="text-lg font-semibold text-gray-800 mb-4">Recent Activity</h2>
                  <div className="space-y-4">
                    {recentActivity.map((activity, index) => (
                      <div key={index} className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors duration-200">
                        <div className="p-2 bg-purple-50 rounded">
                          {activity.type === 'data' && <Database className="w-4 h-4 text-purple-600" />}
                          {activity.type === 'decisions' && <Brain className="w-4 h-4 text-purple-600" />}
                          {activity.type === 'automations' && <Workflow className="w-4 h-4 text-purple-600" />}
                          {activity.type === 'communications' && <MessageSquare className="w-4 h-4 text-purple-600" />}
                        </div>
                        <div>
                          <p className="text-sm text-gray-600">{activity.message}</p>
                          <p className="text-xs text-gray-400 mt-1">{activity.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </>
          )}
        </main>
      </div>

      {/* Chat Panel */}
      <ChatPanel isOpen={isChatOpen} onClose={() => setIsChatOpen(false)} />

      {/* Chat Toggle Button */}
      <button
        onClick={() => setIsChatOpen(!isChatOpen)}
        className="fixed bottom-6 right-6 p-4 bg-purple-600 text-white rounded-full shadow-lg hover:bg-purple-700 transition-colors"
      >
        <MessageCircle className="w-6 h-6" />
      </button>

      {/* Help Overlay */}
      {showHelp && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center animate-fade-in">
          <div className="bg-white rounded-lg p-6 max-w-md">
            <h2 className="text-xl font-semibold mb-4">Help & Resources</h2>
            <p className="text-gray-600 mb-4">
              Need help getting started? Here are some resources to help you make the most of Ciro AI.
            </p>
            <button 
              onClick={() => setShowHelp(false)}
              className="btn-primary w-full justify-center"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;